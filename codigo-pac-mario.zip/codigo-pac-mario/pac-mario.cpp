#include <utility>
#include <SFML/Graphics.hpp>
#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <ctime>
#include <SFML/Audio.hpp>

using namespace std;
using namespace sf;

// g++ pac-mario.cpp -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio

char mapa[15][21] = {        // Mapa do jogo
    "11111111111111111111",
    "1****1****111******1",
    "1*11*1*11*****1*11*1",
    "1*11***************1",
    "1******11*1*1*11***1",
    "1****1*11*1*1*11*1*1",
    "1*1111***********1*1",
    "1***11*1*******1***1",
    "111****1*11*11*1***1",
    "1*****11*******111*1",
    "1*1***1***111***1**1",
    "1***1***1*****1****1",
    "11111111111111111111"};

    //1 - barreiras   *- moedas
    

bool win = false;       //check se usuario venceu
bool loose = false;     //check se venceu (perdeu as 3 vidas)
bool congela = false;   //impede a movimentacao dos personagens apos o fim da partida
bool reset = false;     //recomeco do jogo
int cont = 0;           //contador de moedas coletadas
int score_inicial = 0;  //pontuacao
int minutes, segundos;  
int vida = 3;           //3 vidas do jogador
int menu=true;          //abre menu principal do jogo
bool mario=false;       //jogar com o luigi ou com o mario

float second;           //tempo percorrido

int posx = 11;          // posicao do PacMan
int posy = 9;
int initx = posx;       //posicao de nascimento do PanMan
int inity = posy;

// posicao do fantasma 1
int fan1x = 2;
int fan1y = 5;
int init_fan1_x = fan1x;
int init_fan1_y = fan1y;
int ultimo_mov_fan1=1;  

// posicao do fantasma 2
int fan2x = 18;
int fan2y = 5;
int init_fan2_x = fan2x;
int init_fan2_y = fan2y;
int ultimo_mov_fan2=1;

// posicao do fantasma 3
int fan3x = 3;
int fan3y = 14;
int init_fan3_x = fan3x;
int init_fan3_y = fan3y;
int ultimo_mov_fan3=1;

// posicao do fantasma 4
int fan4x = 15;
int fan4y = 14;
int init_fan4_x = fan4x;
int init_fan4_y = fan4y;
int ultimo_mov_fan4=1;

// direcao de movimento
bool cima = false;
bool baixo = false;
bool esq = false;
bool dir = false;

//direcao que o personagem esta olhando
bool olhadireita = true;
bool olhacima = false;
bool olhabaixo = false;
bool olhaesquerda = false;

int main()
{

    srand(time(0));    //declaracao para movimento aleatorio dos fantasmas


    //tamanho da janela
    const int altura = 800;   
    const int largura = 680;
    sf::RenderWindow window(sf::VideoMode(altura, largura), "Pac-Mario");

    // shape de fundo preto

    sf::RectangleShape rectangle(sf::Vector2f(40, 40));
    rectangle.setFillColor(sf::Color(0, 0, 0));

    //sprite menu
    sf::Texture menu_fundo;
    if (!menu_fundo.loadFromFile("menu.png"))
    {
        std::cout << "Erro lendo imagem menu.png\n";
        return 0;
    }
    sf::Sprite spritemenu;
    spritemenu.setTexture(menu_fundo);

     sf::Texture menu_pers;
    if (!menu_pers.loadFromFile("escolha_menu.png"))
    {
        std::cout << "Erro lendo imagem escolha_menu.png\n";
        return 0;
    }
    sf::Sprite spritemenu_pers;
    spritemenu_pers.setTexture(menu_pers);

    // mensagem do menu
    sf::Font fonte;
    fonte.loadFromFile("ARCADEPI.TTF");

    sf::Text textmenu;
    textmenu.setFont(fonte); // font is a sf::Font
    textmenu.setString("Pressione <- para jogar com\n o Luigi ou -> para o Mario");
    textmenu.setCharacterSize(18); // in pixels, not points!
    textmenu.setFillColor(sf::Color::White);



    //-------------PERSONAGENS---------------//
    
    //---SPRITE DO MARIO--//
    sf::Texture texture;
    if (!texture.loadFromFile("mario.png"))
    {
        std::cout << "Erro lendo imagem mario.png\n";
        return 0;
    }

    sf::Sprite spritedir;
    spritedir.setTexture(texture);

    sf::Texture texture2;
    if (!texture2.loadFromFile("mario_esq.png"))
    {
        std::cout << "Erro lendo imagem mario_esq.png\n";
        return 0;
    }
    sf::Sprite spriteesq;
    spriteesq.setTexture(texture2);

    sf::Texture texture3;
    if (!texture3.loadFromFile("mario_baixo.png"))
    {
        std::cout << "Erro lendo imagem mario_baixo.png\n";
        return 0;
    }
    sf::Sprite spritebaixo;
    spritebaixo.setTexture(texture3);

    sf::Texture texture4;
    if (!texture4.loadFromFile("mario_cima.png"))
    {
        std::cout << "Erro lendo imagem mario_cima.png\n";
        return 0;
    }
    sf::Sprite spritecima;
    spritecima.setTexture(texture4);




    //---SPRITE LUIGI---//

    sf::Texture luigi_dir;
    if (!luigi_dir.loadFromFile("luigi_dir.png"))
    {
        std::cout << "Erro lendo imagem luigidir.png\n";
        return 0;
    }

    sf::Sprite sprite_luigi_dir;
    sprite_luigi_dir.setTexture(luigi_dir);

    sf::Texture luigi_esq;
    if (!luigi_esq.loadFromFile("luigi_esq.png"))
    {
        std::cout << "Erro lendo imagem luigi_esq.png\n";
        return 0;
    }
    sf::Sprite sprite_luigi_esq;
    sprite_luigi_esq.setTexture(luigi_esq);

    sf::Texture luigi_baixo;
    if (!luigi_baixo.loadFromFile("luigi_baixo.png"))
    {
        std::cout << "Erro lendo imagem luigi_baixo.png\n";
        return 0;
    }
    sf::Sprite sprite_luigi_baixo;
    sprite_luigi_baixo.setTexture(luigi_baixo);

    sf::Texture luigi_cima;
    if (!luigi_cima.loadFromFile("luigi_cima.png"))
    {
        std::cout << "Erro lendo imagem mario_cima.png\n";
        return 0;
    }
    sf::Sprite sprite_luigi_cima;
    sprite_luigi_cima.setTexture(luigi_cima);


    //----SPRITE FANTASMA---//
    sf::Texture fantasma;
    if (!fantasma.loadFromFile("fantasma_goomba.png"))
    {
        std::cout << "Erro lendo imagem fantasma_goomba.png\n";
        return 0;
    }
    sf::Sprite sprite_fantasma;
    sprite_fantasma.setTexture(fantasma);

    // sprite vida
    sf::Texture chances;
    if (!chances.loadFromFile("cogumelo.png"))
    {
        std::cout << "Erro lendo imagem cogumelo.png\n";
        return 0;
    }
    sf::Sprite sprite_chances;
    sprite_chances.setTexture(chances);

    //sprite estrelas
    sf::Texture estrela;
    if (!estrela.loadFromFile("estrela.png"))
    {
    std::cout << "Erro lendo imagem  estrela.png\n";
        return 0;
    }
    sf::Sprite sprite_estrela;
    sprite_estrela.setTexture(estrela);

    //----------------------------------------//


    // sprite da comida

    sf::Texture comida;
    if (!comida.loadFromFile("moeda_mario.png"))
    {
        std::cout << "Erro lendo imagem comida.png\n";
        return 0;
    }
    sf::Sprite spritecomida;
    spritecomida.setTexture(comida);

    //  texto de vitória
    
    sf::Text textvitoria;
    textvitoria.setFont(fonte);             // font is a sf::Font
    textvitoria.setString("Voce Ganhou!");
    textvitoria.setCharacterSize(50);       // in pixels, not points!
    textvitoria.setFillColor(sf::Color::Yellow);

    // mensagem de derrota

    sf::Text textderrota;
    textderrota.setFont(fonte);             // font is a sf::Font
    textderrota.setString("Game\nOver!\n");
    textderrota.setCharacterSize(50);       // in pixels, not points!
    textderrota.setFillColor(sf::Color::Red);

    // time out
    sf::Text texttimeout;
    texttimeout.setFont(fonte);             // font is a sf::Font
    texttimeout.setString(" Tempo\nEsgotado!\n");
    texttimeout.setCharacterSize(50);       // in pixels, not points!
    texttimeout.setFillColor(sf::Color::Red);

    // mensagem suporte de reiniciar o jogo
    sf::Text textreiniciar;
    textreiniciar.setFont(fonte);           // font is a sf::Font
    textreiniciar.setString("Pressione Enter para reiniciar.\n");
    textreiniciar.setCharacterSize(18);     // in pixels, not points!
    textreiniciar.setFillColor(sf::Color::Black);

    // mensagem de vidas
    sf::Text textvidas;
    textvidas.setFont(fonte);              // font is a sf::Font
    textvidas.setCharacterSize(24);        // in pixels, not points!
    textvidas.setFillColor(sf::Color::Yellow);
    textvidas.setPosition(600, 40);

    // score
    sf::Text scoreteste;
    scoreteste.setFont(fonte);                  // Configura a fonte
    scoreteste.setCharacterSize(24);            // Tamanho da fonte
    scoreteste.setFillColor(sf::Color::Yellow); // Cor do texto
    scoreteste.setPosition(600, 10);            // Posição do texto na tela

    //--------BLOCOS DO MAPA--------//

    //bloco amarelo
    sf::Texture bloco_luck;
    if (!bloco_luck.loadFromFile("luck.png"))
    {
        std::cout << "Erro lendo imagem luck.png\n";
        return 0;
    }
    sf::Sprite spritebloco_luck;
    spritebloco_luck.setTexture(bloco_luck);

    //bloco exterior 
    sf::Texture bloco_marrom;
    if (!bloco_marrom.loadFromFile("bloco_mario.png"))
    {
        std::cout << "Erro lendo imagem bloco_mario.png\n";
        return 0;
    }
    sf::Sprite spritebloco_marrom;
    spritebloco_marrom.setTexture(bloco_marrom);

    // imagem de vitoria
    sf::Texture vitoria_img;
    if (!vitoria_img.loadFromFile("mario_vitoria.png"))
    {
        std::cout << "Erro lendo imagem mario_vitoria.png\n";
        return 0;
    }
    sf::Sprite spritevitoria_img;
    spritevitoria_img.setTexture(vitoria_img);

    //-----------------------------------------//

    // texto do temporizador e declaracao de clocks
    Text clock2;
    clock2.setFont(fonte);                  // Configura a fonte
    clock2.setCharacterSize(24);            // Tamanho da fonte
    clock2.setFillColor(sf::Color::Yellow); // Cor do texto
    clock2.setPosition(0, 0);               // Posição do texto na tela
    const float timeLimit = 100.0f;         // limite do tempo do jogo

    sf::Clock clock; // relogio do personagem
    // cria um relogio para medir o tempo
    Clock clock3;
    // relogio do fantasma
    sf::Clock clockFantasma; // Cronômetro para o fantasma

    //------MENU SUPERIOR----//
    sf::Texture superior;
    if (!superior.loadFromFile("fundo_ceu.png"))
    {
        std::cout << "Erro lendo imagem fundo_superior.png\n";
        return 0;
    }
    sf::Sprite sprite_superior;
    sprite_superior.setTexture(superior);


    //-------MUSICAS-----//

    Music musica;
    if (!musica.openFromFile("Musica.ogg")) {
    return -1; // Lidar com erro
    }

    Music musica_vitoria;
    if (!musica_vitoria.openFromFile("level_complete.ogg")) {
    return -1; // Lidar com erro
    }

    Music musica_gameover;
    if (!musica_gameover.openFromFile("musica_gameover.ogg")) {
    return -1; // Lidar com erro
    }
    //contadores para impedir looping
    int cont_gameover=0;
    int cont_vitoria=0;   

    bool personagemSeMove = false; // se o personagem se mover começa a musica
    bool win = false;              // Estado do jogo

    // executa o programa enquanto a janela está aberta
    sf::Event event;

    while (window.isOpen())  {

        if (win || loose)
            congela = true;
       
        // verifica todos os eventos que foram acionados na janela desde a última iteração do loop
        
        while (window.pollEvent(event))
        {    
            // evento "fechar" acionado: fecha a janela
            if (event.type == sf::Event::Closed)
                window.close();

             if (menu) {  //se estivermos na tela de menu
                congela=true;  //impede que personagens se movam antes do jogo iniciar
                mario=false;   //selecao de perosnagem
                
                // Lógica do menu
                if (event.type == sf::Event::KeyPressed) {
                    if (event.key.code == sf::Keyboard::Right) {
                        // Selecionar Mario
                        mario=true;
                        menu = false;
                        // Código para iniciar o jogo com Mario
                    } else if (event.key.code == sf::Keyboard::Left) {
                        // Selecionar Luigi
                        menu = false;
                        // Código para iniciar o jogo com Luigi
                    }
                }
            } 
                
            
            
            // Detecta se o personagem se move
            bool personagemSeMove = false;
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left) ||
                sf::Keyboard::isKeyPressed(sf::Keyboard::Right) ||
                sf::Keyboard::isKeyPressed(sf::Keyboard::Up) ||
                sf::Keyboard::isKeyPressed(sf::Keyboard::Down)||
                sf::Keyboard::isKeyPressed(sf::Keyboard::A)||
                sf::Keyboard::isKeyPressed(sf::Keyboard::D)||
                sf::Keyboard::isKeyPressed(sf::Keyboard::W)||
                sf::Keyboard::isKeyPressed(sf::Keyboard::S))
            {
                personagemSeMove = true;
            }

            // Inicia a música se o personagem começar a se mover e a música não estiver tocando
            if (personagemSeMove &&!menu&& musica.getStatus() != sf::Music::Playing) {
                musica.play();
                musica.setLoop(true);
            }

            // tecla pressionada
            if (event.type == sf::Event::KeyPressed)
            {
                if (event.key.code == sf::Keyboard::Escape)
                {
                    window.close();
                }

                // Reinicia o personagem
                if (event.key.code == sf::Keyboard::Enter)
                {
                    musica.stop();
                    musica.play();               

                    posx = initx;
                    posy = inity;
                    fan1x = init_fan1_x;
                    fan1y = init_fan1_y;
                    fan2x = init_fan2_x;
                    fan2y = init_fan2_y;
                    fan3x = init_fan3_x;
                    fan3y = init_fan3_y;
                    fan4x = init_fan4_x;
                    fan4y = init_fan4_y;
                    vida = 3;
                    reset = true;
                    esq = dir = cima = baixo = false;
                    score_inicial = 0;
                }

                if (congela == false)
                {
                    if (event.key.code == sf::Keyboard::Left || event.key.code == sf::Keyboard::A)
                    {
                        olhadireita = olhabaixo = olhacima = false;
                        olhaesquerda = true;

                        //caso nao seja possivel se mover pra nova direcao, continuar a anterior
                        if(mapa[posy - 4][posx - 1] != '1'){
                            esq = true; // left key: PacMan passa a mover para esquerda
                            dir = cima = baixo = false;
                        }
                    }

                    else if (event.key.code == sf::Keyboard::Right || event.key.code == sf::Keyboard::D)
                    {
                        olhadireita = true;
                        olhaesquerda = olhabaixo = olhacima = false;

                        //caso nao seja possivel se mover pra nova direcao, continuar a anterior
                        if(mapa[posy - 4][posx + 1] != '1'){
                            dir = true; // right key: PacMan passa a mover para direita
                            esq = cima = baixo = false;
                        }
                        
                    }
                    else if (event.key.code == sf::Keyboard::Up || event.key.code == sf::Keyboard::W)
                    {
                        olhacima = true;
                        olhadireita = olhabaixo = olhaesquerda = false;

                        //caso nao seja possivel se mover pra nova direcao, continuar a anterior
                        if (mapa[posy - 4 - 1][posx] != '1'){
                            cima = true; // up key: PacMan passa a mover para cima
                            esq = dir = baixo = false;
                        }
                    }
                    else if (event.key.code == sf::Keyboard::Down || event.key.code == sf::Keyboard::S)
                    {
                        olhabaixo = true;
                        olhadireita = olhaesquerda = olhacima = false;

                        //caso nao seja possivel se mover pra nova direcao, continuar a anterior
                        if(mapa[posy - 4 + 1][posx] != '1'){
                            baixo = true; // down key:PacMan passa a mover para baixo
                            esq = dir = cima = false;
                        }
                        
                    }
                }
            }
        }

        if (congela == false)
        {
            second = clock3.getElapsedTime().asSeconds();

            // Converte o tempo decorrido para minutos e segundos
            minutes = static_cast<int>(second) / 60;
            segundos = static_cast<int>(second) % 60;
            if(second>120)
            loose=true;
            // Atualiza o texto com o tempo formatado
            clock2.setString("Time: " + std::to_string(minutes) + " min " + std::to_string(segundos) + " s");
            
        }

        // Muda a posição do PacMan a cada 0.2 segundos
        if (clock.getElapsedTime() > sf::seconds(0.2))
        {                    // tempo desde último restart > 0.2s
            clock.restart(); // recomeça contagem do tempo
            

            if (reset)  //caso de jogar uma nova partida
            {
                //redesenhando o mapa
                for (int i = 0; i < 15; i++)
                    for (int j = 0; j < 21; j++)
                        if (mapa[i][j] == '0')
                            mapa[i][j] = '*';

                reset = false;   
                congela = false;    //inicia o jogo
                win = false;        
                loose = false;
                clock3.restart();
                clockFantasma.restart();
                musica_gameover.stop();
                musica_vitoria.stop();   
                menu=true;
                dir=esq=baixo=cima=false; //impede que personagem nasce ja andando
                cont_gameover=0;  //contador de musica
                cont_vitoria=0;   //contador de musica
            }


            if ((olhacima||cima) && mapa[posy - 4 - 1][posx] != '1')
            {
                if(cima)
                    posy--;     // muda a posição de acordo com booleano ativo
                cima=true;      //garante intensao de movimento
                baixo=esq=dir=false;
                
                if (mapa[posy - 4][posx] == '*')
                    score_inicial++;
                
            }
            else if ((olhabaixo||baixo) && mapa[posy - 4 + 1][posx] != '1')
            {
                if(baixo)
                    posy++;
                baixo=true;      //garante intensao de movimento
                cima=esq=dir=false;
                if (mapa[posy - 4][posx] == '*')
                    score_inicial++;
                
            }
            if ((olhaesquerda||esq) && mapa[posy - 4][posx - 1] != '1')
            {
                if(esq)
                    posx--;
                esq=true;       //garante intensao de movimento
                dir=baixo=cima=false;
                if (mapa[posy - 4][posx] == '*')
                    score_inicial++;
                
            }
            if ((olhadireita||dir) && mapa[posy - 4][posx + 1] != '1')
            {
                if(dir)
                    posx++;
                dir=true;       //garante intensao de movimento
                esq=cima=baixo=false;
                if (mapa[posy - 4][posx] == '*')
                    score_inicial++;
                
            }

            // verificando se o fantasma 'comeu' o personagem
            if (fan1y == posy && fan1x == posx || fan2y == posy && fan2x == posx || fan3y == posy && fan3x ==posx || fan4y == posy && fan4x ==posx)
            {
                if(!loose&&!win){
                    vida -= 1;
                    olhacima=olhabaixo=olhaesquerda=false;
                    olhadireita=true;
                    esq=dir=cima=baixo=false;  //impede que, no respawn, o personagem nasce andando
                }
                posx = initx;
                posy = inity;
                if (vida == 0)
                    loose = true;
                esq=dir=cima=baixo=false;
                
            }

            if (clockFantasma.getElapsedTime() > sf::seconds(0.6))
            {                            // tempo desde último restart > 0.2s?
                clockFantasma.restart(); // recomeça contagem do tempo

                // acoes do fantasma 1
                bool instrucao_valida_fan1 = false;
                int acao_fantasma=3;
                

                // 0- cima; 1-esquerda; 2-baixo 3-direita
                while (instrucao_valida_fan1 == false && !loose && !win&&!menu)
                {   
                
                    //impedindo se mover pra posicao anterior
                    acao_fantasma = rand() % 4;             //movimentacao aleatoria de intervalo [0,3]
                    while(acao_fantasma==ultimo_mov_fan1)   //impede que o fantasma volte pra posicao anterior, seguindo um fluxo de movimento
                        acao_fantasma = rand() % 4;

                        
                    if (acao_fantasma == 0)
                    {
                        if (mapa[fan1y - 4 - 1][fan1x] != '1')
                        {
                            fan1y--;
                            instrucao_valida_fan1 = true;
                            ultimo_mov_fan1=2;
                        }
                    }
                    else if (acao_fantasma == 1)
                    {
                        if (mapa[fan1y - 4][fan1x - 1] != '1')
                        {
                            fan1x--;
                            instrucao_valida_fan1 = true;
                            ultimo_mov_fan1=3;
                        }
                    }
                    else if (acao_fantasma == 2)
                    {
                        if (mapa[fan1y - 4 + 1][fan1x] != '1')
                        {
                            fan1y++;
                            instrucao_valida_fan1 = true;
                            ultimo_mov_fan1=0;
                        }
                    }
                    else if (acao_fantasma == 3)
                    {
                        if (mapa[fan1y - 4][fan1x + 1] != '1')
                        {
                            fan1x++;
                            instrucao_valida_fan1 = true;
                            ultimo_mov_fan1=1;
                        }
                    }
                }
                
                // acoes do fantasma 2
                bool instrucao_valida_fan2 = false;

                // 0- cima; 1-esquerda; 2-baixo 3-direita
                while (instrucao_valida_fan2 == false && !loose && !win&&!menu)
                {
                     //impedindo se mover pra posicao anterior
                    acao_fantasma = rand() % 4;
                    while(acao_fantasma==ultimo_mov_fan2)   //impede que o fantasma volte pra posicao anterior, seguindo um fluxo de movimento
                        acao_fantasma = rand() % 4;

                    if (acao_fantasma == 0)
                    {
                        if (mapa[fan2y - 4 - 1][fan2x] != '1')
                        {
                            fan2y--;
                            instrucao_valida_fan2 = true;
                            ultimo_mov_fan2=2;
                        }
                    }
                    else if (acao_fantasma == 1)
                    {
                        if (mapa[fan2y - 4][fan2x - 1] != '1')
                        {
                            fan2x--;
                            instrucao_valida_fan2 = true;
                            ultimo_mov_fan2=3;
                        }
                    }
                    else if (acao_fantasma == 2)
                    {
                        if (mapa[fan2y - 4 + 1][fan2x] != '1')
                        {
                            fan2y++;
                            instrucao_valida_fan2 = true;
                            ultimo_mov_fan2=0;
                        }
                    }
                    else if (acao_fantasma == 3)
                    {
                        if (mapa[fan2y - 4][fan2x + 1] != '1')
                        {
                            fan2x++;
                            instrucao_valida_fan2 = true;
                            ultimo_mov_fan2=1;
                        }
                    }
                }

                // acoes do fantasma 3
                bool instrucao_valida_fan3 = false;

                // 0- cima; 1-esquerda; 2-baixo 3-direita
                while (instrucao_valida_fan3 == false && !loose && !win&&!menu)
                {
                    //impedindo se mover pra posicao anterior
                    acao_fantasma = rand() % 4;
                    while(acao_fantasma==ultimo_mov_fan3)      //impede que o fantasma volte pra posicao anterior, seguindo um fluxo de movimento
                        acao_fantasma = rand() % 4;

                    if (acao_fantasma == 0)
                    {
                        if (mapa[fan3y - 4 - 1][fan3x] != '1')
                        {
                            fan3y--;
                            instrucao_valida_fan3 = true;
                            ultimo_mov_fan3=2;
                        }
                    }
                    else if (acao_fantasma == 1)
                    {
                        if (mapa[fan3y - 4][fan3x - 1] != '1')
                        {
                            fan3x--;
                            instrucao_valida_fan3 = true;
                            ultimo_mov_fan3=3;
                        }
                    }
                    else if (acao_fantasma == 2)
                    {
                        if (mapa[fan3y - 4 + 1][fan3x] != '1')
                        {
                            fan3y++;
                            instrucao_valida_fan3 = true;
                            ultimo_mov_fan3=0;
                        }
                    }
                    else if (acao_fantasma == 3)
                    {
                        if (mapa[fan3y - 4][fan3x + 1] != '1')
                        {
                            fan3x++;
                            instrucao_valida_fan3 = true;
                            ultimo_mov_fan3=1;
                        }
                    }
                }

                // acoes do fantasma 4
                bool instrucao_valida_fan4 = false;

                // 0- cima; 1-esquerda; 2-baixo 3-direita
                while (instrucao_valida_fan4 == false && !loose && !win&&!menu)
                {
                    //impedindo se mover pra posicao anterior
                    acao_fantasma = rand() % 4;
                    while(acao_fantasma==ultimo_mov_fan4)  //impede que o fantasma volte pra posicao anterior, seguindo um fluxo de movimento
                        acao_fantasma = rand() % 4;

                    if (acao_fantasma == 0)
                    {
                        if (mapa[fan4y - 4 - 1][fan4x] != '1')
                        {
                            fan4y--;
                            instrucao_valida_fan4 = true;
                            ultimo_mov_fan4=2;
                        }
                    }
                    else if (acao_fantasma == 1)
                    {
                        if (mapa[fan4y - 4][fan4x - 1] != '1')
                        {
                            fan4x--;
                            instrucao_valida_fan4 = true;
                            ultimo_mov_fan4=3;
                        }
                    }
                    else if (acao_fantasma == 2)
                    {
                        if (mapa[fan4y - 4 + 1][fan4x] != '1')
                        {
                            fan4y++;
                            instrucao_valida_fan4 = true;
                            ultimo_mov_fan4=0;
                        }
                    }
                    else if (acao_fantasma == 3)
                    {
                        if (mapa[fan4y - 4][fan4x + 1] != '1')
                        {
                            fan4x++;
                            instrucao_valida_fan4 = true;
                            ultimo_mov_fan4=1;
                        }
                    }
                }

                // verificando se o fantasma 'comeu' o personagem
                if (fan1y == posy && fan1x == posx || fan2y == posy && fan2x == posx || fan3y == posy && fan3x ==posx || fan4y == posy && fan4x ==posx)
                {
                     if(!loose&&!win){
                    vida -= 1;
                    olhacima=olhabaixo=olhaesquerda=false;
                    olhadireita=true;
                    esq=dir=cima=baixo=false;
                    
                }
                    posx = initx;
                    posy = inity;
                    if (vida == 0)
                        loose = true;
                    esq=dir=cima=baixo=false;
                    
                }
            }
        }

         // limpa a janela com a cor preta
                window.clear(sf::Color::Black);

        // desenhar tudo aqui...
        
 if(menu){
    //desenhando o menu principal

    spritemenu.setPosition(0,0);
    window.draw(spritemenu);

    spritemenu_pers.setPosition(300,400);
    window.draw(spritemenu_pers);
    


    textmenu.setPosition(230,309);
    window.draw(textmenu);
    window.display();
    clock3.restart();
 }
 else{
    congela=false;
    
        // fundo superior

        for (int i = 0; i < 15; i++)
        {
            for (int j = 0; j < 21; j++)
            {
                if (mapa[i][j] == '1')
                {

                    if (i == 0 || i == 12 || j == 0 || j == 19)
                    {
                        spritebloco_marrom.setPosition(j * 40, (i + 4) * 40);
                        window.draw(spritebloco_marrom);
                    }
                    else
                    {
                        spritebloco_luck.setPosition(j * 40, (i + 4) * 40);
                        window.draw(spritebloco_luck);
                    }
                }
            }
        }

        for (int i = 0; i < 15; i++)
            for (int j = 0; j < 21; j++)
                if (mapa[i][j] == '*')
                {
                    spritecomida.setPosition(j * 40 + 5+3, (i + 4) * 40+5+3);
                    window.draw(spritecomida);
                }

        // apaga o objeto pegado
        mapa[posy - 4][posx] = '0';

        sprite_superior.setPosition(0, 0);
        window.draw(sprite_superior);

        // desenho das vidas
        textvidas.setString(to_string(vida) + "X");
        window.draw(textvidas);

        sprite_chances.setPosition(650, 40);
        window.draw(sprite_chances);

        // desenho do score
        scoreteste.setString("Pontos: " + to_string(score_inicial * 100 / 138) + "%");
        window.draw(scoreteste);

        // clock
        window.draw(clock2);
        

        // desenha PacMan
        if (olhadireita)
        {
            if(mario){
                spritedir.setPosition(posx * 40, posy * 40);
                window.draw(spritedir);
            }
            else{
                sprite_luigi_dir.setPosition(posx * 40, posy * 40);
                window.draw(sprite_luigi_dir);
            }


        }
        else if (olhaesquerda)
        {
            if(mario){
                spriteesq.setPosition(posx * 40, posy * 40);
                window.draw(spriteesq);
            }
            else{
                sprite_luigi_esq.setPosition(posx * 40, posy * 40);
                window.draw(sprite_luigi_esq);
            }
            
        }
        else if (olhacima)
        {
            if(mario){
                spritecima.setPosition(posx * 40, posy * 40);
                window.draw(spritecima);
            }
            else{
                sprite_luigi_cima.setPosition(posx * 40, posy * 40);
                window.draw(sprite_luigi_cima);
            }
        }
        else if (olhabaixo)
        {
            if(mario){
                spritebaixo.setPosition(posx * 40, posy * 40);
                window.draw(spritebaixo);
            }
            else{
                sprite_luigi_baixo.setPosition(posx * 40, posy * 40);
                window.draw(sprite_luigi_baixo);
            }
        }
        

        // desenha fantasma 1
        sprite_fantasma.setPosition(fan1x * 40, fan1y * 40);
        window.draw(sprite_fantasma);

        // desenha fantasma 2
        sprite_fantasma.setPosition(fan2x * 40, fan2y * 40);
        window.draw(sprite_fantasma);

        // desenha fantasma 3
        sprite_fantasma.setPosition(fan3x * 40, fan3y * 40);
        window.draw(sprite_fantasma);

        // desenha fantasma 4
        sprite_fantasma.setPosition(fan4x * 40, fan4y * 40);
        window.draw(sprite_fantasma);

        //confere se ganhou
        cont = 0;
        for (int i = 0; i < 15; i++)
            for (int j = 0; j < 21; j++)
                if (mapa[i][j] == '*')
                {
                    cont++;
                }

        if (cont == 0)
            win = true;

        // imagem de vitoria
        if (win)
        {
            spritevitoria_img.setPosition(0, 0);
            window.draw(spritevitoria_img);

            for (int i = 1; i < 15 - 1; i++)
                for (int j = 1; j < 21 - 1; j++)
                    rectangle.setPosition(j * 40 + 5, (i + 4) * 40);
            window.draw(rectangle);

            for(int i=0; i<vida; i++){
                sprite_estrela.setPosition(300+55*i,20);
                window.draw(sprite_estrela);
            }

            textvitoria.setPosition(200, 70);
            textreiniciar.setPosition(220, 135);
            window.draw(textvitoria);
            window.draw(textreiniciar);            
            esq = dir = baixo = cima = false;
            musica.stop();
            if ( musica_vitoria.getStatus() != sf::Sound::Playing&&cont_vitoria==0){
                musica_vitoria.play();
                cont_vitoria++;
            }
        }

        if (loose)
        {

            for (int i = 1; i < 15 - 1; i++)
                for (int j = 1; j < 21 - 1; j++)
                    rectangle.setPosition(j * 40 + 5, (i + 4) * 40);
            window.draw(rectangle);

            if(second<120){
            textderrota.setPosition(325, 30);
            textreiniciar.setPosition(220, 135);
            window.draw(textderrota);
            window.draw(textreiniciar);
            }
                else{
                    texttimeout.setPosition(260, 20);
                    textreiniciar.setPosition(220, 135);
                    window.draw(texttimeout);
                    window.draw(textreiniciar);
                }

            esq = dir = baixo = cima = false;
            musica.stop();
            if ( musica_gameover.getStatus() != sf::Sound::Playing&&cont_gameover==0){
                musica_gameover.play();
                cont_gameover++;
            }
        }

        // termina e desenha o frame corrente
        window.display();
    }
}  

    return 0;
}
